const fs = require("fs");
const path = require("path");
const PDFDocument = require("pdfkit");
const { LETTERS_DIR } = require("../config/uploadPaths");
const { OfficialLetter } = require("../models/letter.model");
const { User, Stakeholder, Project } = require("../models/index");
const { sendLetterEmail } = require("../utils/mailer");
const {
  successResponse,
  errorResponse,
  paginatedResponse,
  getPagination,
} = require("../utils/response");
const { Op } = require("sequelize");

const USER_INCLUDES = [
  { model: User, as: "createdBy", attributes: ["id", "firstName", "lastName"] },
  { model: User, as: "approvedBy", attributes: ["id", "firstName", "lastName"] },
  { model: User, as: "sentBy", attributes: ["id", "firstName", "lastName"] },
  { model: User, as: "sender", attributes: ["id", "firstName", "lastName", "email", "jobTitle", "department"] },
  { model: Stakeholder, as: "recipient", attributes: ["id", "name", "organization", "jobTitle", "email", "phone"] },
  { model: Project, as: "project", attributes: ["id", "name", "projectCode"] },
];

const generateLetterNo = async (projectId) => {
  if (projectId) {
    const project = await Project.findByPk(projectId);
    const prefix = project && project.projectCode ? project.projectCode : "PRJ";
    const count = await OfficialLetter.count({ where: { projectId } });
    const sequence = String(count + 1).padStart(3, "0");
    return `${prefix}/LTR/${sequence}`;
  } else {
    const year = new Date().getFullYear();
    const count = await OfficialLetter.count({ where: { projectId: null } });
    return `LTR-${year}-${String(count + 1).padStart(4, "0")}`;
  }
};

// ══════════════════════════════════════════════════════════════
// LIST / CRUD
// ══════════════════════════════════════════════════════════════

// GET /api/letters  (jumla, si za project moja)
// GET /api/projects/:projectId/letters
exports.listLetters = async (req, res, next) => {
  try {
    const { page, limit, offset } = getPagination(req.query);
    const { status, type, priority, search, projectId: queryProjectId, clientId } = req.query;
    const { projectId } = req.params;

    const where = {};
    
    const targetProjectId = projectId || queryProjectId;
    if (targetProjectId) {
      where.projectId = targetProjectId;
    } else if (clientId) {
      const projects = await Project.findAll({ where: { clientId }, attributes: ["id"] });
      const projectIds = projects.map(p => p.id);
      where.projectId = { [Op.in]: projectIds };
    }

    if (status) {
      const statusMap = {
        draft: "Draft",
        pending_approval: "Pending Approval",
        approved: "Approved",
        sent: "Sent",
        archived: "Archived"
      };
      where.status = statusMap[status.toLowerCase()] || status;
    }

    if (type) where.type = type;
    if (priority) where.priority = priority;

    if (search) {
      where[Op.or] = [
        { subject: { [Op.like]: `%${search}%` } },
        { recipientName: { [Op.like]: `%${search}%` } },
        { letterNo: { [Op.like]: `%${search}%` } },
      ];
    }

    const { count, rows } = await OfficialLetter.findAndCountAll({
      where,
      include: USER_INCLUDES,
      order: [["createdAt", "DESC"]],
      limit,
      offset,
    });

    return paginatedResponse(res, rows, count, page, limit);
  } catch (err) {
    next(err);
  }
};

const formatLetterResponse = async (letter) => {
  if (!letter) return null;
  const letterData = letter.toJSON();
  
  let ccRecipients = [];
  if (letter.ccList && letter.ccList.length) {
    const ids = [];
    const manual = [];
    letter.ccList.forEach(item => {
      if (typeof item === "string") ids.push(item);
      else if (item && typeof item === "object") {
        if (item.id) ids.push(item.id);
        else manual.push(item);
      }
    });
    if (ids.length) {
      const dbStakeholders = await Stakeholder.findAll({ where: { id: ids } });
      ccRecipients = [
        ...dbStakeholders.map(s => ({
          id: s.id,
          name: s.name,
          title: s.jobTitle,
          email: s.email,
          organization: s.organization
        })),
        ...manual
      ];
    } else {
      ccRecipients = manual;
    }
  }
  letterData.ccRecipients = ccRecipients;
  return letterData;
};

// GET /api/letters/:letterId
exports.getLetter = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId, { include: USER_INCLUDES });
    if (!letter) return errorResponse(res, "Letter not found", 404);
    const letterData = await formatLetterResponse(letter);
    return successResponse(res, { letter: letterData });
  } catch (err) {
    next(err);
  }
};

// POST /api/letters  or /api/projects/:projectId/letters  (multipart/form-data, field "attachment" hiari)
exports.createLetter = async (req, res, next) => {
  try {
    const { projectId: queryProjectId } = req.params;
    const {
      projectId: bodyProjectId,
      subject, subTitle, body, type, letterDate, priority,
      senderId, senderName: bSenderName, senderPosition: bSenderPosition, senderOrganization: bSenderOrganization, senderEmail: bSenderEmail,
      recipientId, recipientName: bRecipientName, recipientPosition: bRecipientPosition, recipientOrganization: bRecipientOrganization, recipientEmail: bRecipientEmail,
      fromName, fromTitle, fromOrg, fromEmail,
      toName, toTitle, toOrg, toEmail,
      ccList,
    } = req.body;

    const projectId = queryProjectId || bodyProjectId || null;
    const senderName = bSenderName || fromName;
    const senderPosition = bSenderPosition || fromTitle;
    const senderOrganization = bSenderOrganization || fromOrg;
    const senderEmail = bSenderEmail || fromEmail;

    const recipientName = bRecipientName || toName;
    const recipientPosition = bRecipientPosition || toTitle;
    const recipientOrganization = bRecipientOrganization || toOrg;
    const recipientEmail = bRecipientEmail || toEmail;

    if (!subject) return errorResponse(res, "Subject is required", 400);
    if (!body) return errorResponse(res, "Body is required", 400);
    if (!recipientId && !recipientName) return errorResponse(res, "Recipient name or ID is required", 400);

    // ccList inaweza kuja kama JSON string (multipart/form-data haitumii JSON moja kwa moja)
    let parsedCc = [];
    if (ccList) {
      try {
        parsedCc = typeof ccList === "string" ? JSON.parse(ccList) : ccList;
      } catch (e) {
        parsedCc = [];
      }
    }

    let letterNo = req.body.letterNo || req.body.referenceNo;
    if (type !== "incoming" || !letterNo) {
      letterNo = await generateLetterNo(projectId);
    }

    const letter = await OfficialLetter.create({
      projectId: projectId || null,
      type: type || "outgoing",
      letterDate: letterDate || new Date(),
      priority: priority || "normal",
      senderId: senderId || req.userId || null,
      recipientId: recipientId || null,
      letterNo,
      subject,
      subTitle: subTitle || null,
      body,
      senderName, senderPosition, senderOrganization, senderEmail,
      recipientName, recipientPosition, recipientOrganization, recipientEmail,
      ccList: parsedCc,
      attachmentFileName: req.file ? req.file.originalname : null,
      attachmentFilePath: req.file ? req.file.filename : null,
      status: "Draft",
      createdById: req.userId,
    });

    const full = await OfficialLetter.findByPk(letter.id, { include: USER_INCLUDES });
    const letterData = await formatLetterResponse(full);
    return successResponse(res, { letter: letterData }, "Letter created", 201);
  } catch (err) {
    if (req.file) fs.unlink(req.file.path, () => {});
    next(err);
  }
};

// PUT /api/letters/:letterId  (metadata pekee — JSON body, si faili)
exports.updateLetter = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId);
    if (!letter) return errorResponse(res, "Letter not found", 404);
    if (letter.status === "Sent")
      return errorResponse(res, "Cannot edit a letter that has already been sent", 400);

    const updateData = { ...req.body };
    if (req.body.fromName) updateData.senderName = req.body.fromName;
    if (req.body.fromTitle) updateData.senderPosition = req.body.fromTitle;
    if (req.body.fromOrg) updateData.senderOrganization = req.body.fromOrg;
    if (req.body.fromEmail) updateData.senderEmail = req.body.fromEmail;

    if (req.body.toName) updateData.recipientName = req.body.toName;
    if (req.body.toTitle) updateData.recipientPosition = req.body.toTitle;
    if (req.body.toOrg) updateData.recipientOrganization = req.body.toOrg;
    if (req.body.toEmail) updateData.recipientEmail = req.body.toEmail;

    await letter.update(updateData);
    const full = await OfficialLetter.findByPk(letter.id, { include: USER_INCLUDES });
    const letterData = await formatLetterResponse(full);
    return successResponse(res, { letter: letterData }, "Letter updated");
  } catch (err) {
    next(err);
  }
};

// POST /api/letters/:letterId/attachment  (badilisha/ongeza attachment, multipart/form-data)
exports.updateAttachment = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId);
    if (!letter) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return errorResponse(res, "Letter not found", 404);
    }
    if (letter.status === "Sent") {
      if (req.file) fs.unlink(req.file.path, () => {});
      return errorResponse(res, "Cannot edit a letter that has already been sent", 400);
    }
    if (!req.file) return errorResponse(res, "File is required", 400);

    if (letter.attachmentFilePath) {
      const oldPath = path.join(LETTERS_DIR, letter.attachmentFilePath);
      if (fs.existsSync(oldPath)) fs.unlink(oldPath, () => {});
    }

    await letter.update({
      attachmentFileName: req.file.originalname,
      attachmentFilePath: req.file.filename,
    });

    return successResponse(res, { letter }, "Attachment updated");
  } catch (err) {
    if (req.file) fs.unlink(req.file.path, () => {});
    next(err);
  }
};

// DELETE /api/letters/:letterId
exports.deleteLetter = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId);
    if (!letter) return errorResponse(res, "Letter not found", 404);
    if (letter.status === "Sent")
      return errorResponse(res, "Cannot delete a letter that has already been sent", 400);

    if (letter.attachmentFilePath) {
      const filePath = path.join(LETTERS_DIR, letter.attachmentFilePath);
      if (fs.existsSync(filePath)) fs.unlink(filePath, () => {});
    }

    await letter.destroy();
    return successResponse(res, null, "Letter deleted");
  } catch (err) {
    next(err);
  }
};

// ══════════════════════════════════════════════════════════════
// WORKFLOW
// ══════════════════════════════════════════════════════════════

// POST /api/letters/:letterId/submit
exports.submitLetter = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId);
    if (!letter) return errorResponse(res, "Letter not found", 404);
    if (letter.status !== "Draft") return errorResponse(res, "Only draft letters can be submitted", 400);

    await letter.update({ status: "Pending Approval" });
    return successResponse(res, { letter }, "Letter submitted for approval");
  } catch (err) {
    next(err);
  }
};

// POST /api/letters/:letterId/approve
exports.approveLetter = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId);
    if (!letter) return errorResponse(res, "Letter not found", 404);
    if (letter.status !== "Pending Approval")
      return errorResponse(res, "Only letters pending approval can be approved", 400);

    await letter.update({
      status: "Approved",
      approvedById: req.userId,
      approvedAt: new Date(),
    });
    return successResponse(res, { letter }, "Letter approved");
  } catch (err) {
    next(err);
  }
};

// POST /api/letters/:letterId/send
// Inatuma email HALISI kwa recipient + CC
exports.sendLetter = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId, { include: USER_INCLUDES });
    if (!letter) return errorResponse(res, "Letter not found", 404);
    if (letter.status !== "Approved")
      return errorResponse(res, "Letter must be approved before sending", 400);

    const recipientEmail = letter.recipient ? letter.recipient.email : letter.recipientEmail;
    if (!recipientEmail)
      return errorResponse(res, "Recipient email is required to send", 400);

    let ccEmails = [];
    if (letter.ccList && letter.ccList.length) {
      if (typeof letter.ccList[0] === "string" || (typeof letter.ccList[0] === "object" && !letter.ccList[0].email)) {
        const stakeholders = await Stakeholder.findAll({
          where: { id: letter.ccList }
        });
        ccEmails = stakeholders.map((s) => s.email).filter(Boolean);
      } else {
        ccEmails = letter.ccList.map((c) => c.email).filter(Boolean);
      }
    }

    const html = await buildLetterHtml(letter);

    const attachments = [];
    if (letter.attachmentFilePath) {
      attachments.push({
        filename: letter.attachmentFileName,
        path: path.join(LETTERS_DIR, letter.attachmentFilePath),
      });
    }

    try {
      const info = await sendLetterEmail({
        to: recipientEmail,
        cc: ccEmails,
        subject: `${letter.letterNo}: ${letter.subject}`,
        html,
        attachments,
      });

      await letter.update({
        status: "Sent",
        sentById: req.userId,
        sentAt: new Date(),
        emailMessageId: info.messageId,
        emailError: null,
      });

      return successResponse(
        res,
        { letter },
        `Letter sent to ${recipientEmail}${ccEmails.length ? ` (cc: ${ccEmails.join(", ")})` : ""}`,
      );
    } catch (emailErr) {
      await letter.update({ emailError: emailErr.message });
      return errorResponse(res, `Failed to send email: ${emailErr.message}`, 500);
    }
  } catch (err) {
    next(err);
  }
};

// POST /api/letters/:letterId/archive
exports.archiveLetter = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId);
    if (!letter) return errorResponse(res, "Letter not found", 404);
    await letter.update({ status: "Archived" });
    return successResponse(res, { letter }, "Letter archived");
  } catch (err) {
    next(err);
  }
};

// GET /api/letters/inbox
// "Inbox" = barua zisizo Draft (zinazohitaji hatua/uangalizi wa mtumiaji: pending
// approval, approved zisizotumwa, au zilizotumwa hivi karibuni)
exports.getInboxLetters = async (req, res, next) => {
  try {
    const { page, limit, offset } = getPagination(req.query);
    const { projectId } = req.params;

    const where = { status: { [Op.ne]: "Draft" } };
    if (projectId) where.projectId = projectId;

    const { count, rows } = await OfficialLetter.findAndCountAll({
      where,
      include: USER_INCLUDES,
      order: [["createdAt", "DESC"]],
      limit,
      offset,
    });

    return paginatedResponse(res, rows, count, page, limit);
  } catch (err) {
    next(err);
  }
};

// GET /api/letters/stats  or  /api/projects/:projectId/letters/stats
exports.getLetterStats = async (req, res, next) => {
  try {
    const { projectId } = req.params;
    const where = {};
    if (projectId) where.projectId = projectId;

    const letters = await OfficialLetter.findAll({ where, attributes: ["status"] });

    const stats = {
      total: letters.length,
      draft: letters.filter((l) => l.status === "Draft").length,
      pendingApproval: letters.filter((l) => l.status === "Pending Approval").length,
      approved: letters.filter((l) => l.status === "Approved").length,
      sent: letters.filter((l) => l.status === "Sent").length,
      archived: letters.filter((l) => l.status === "Archived").length,
      incoming: letters.filter((l) => l.type === "incoming").length,
    };

    return successResponse(res, { stats });
  } catch (err) {
    next(err);
  }
};

// Helper: HTML ya barua (inatumika kwa preview na msingi wa email)
const stripHtml = (html) => {
  if (!html) return "";
  return html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<p>/gi, "")
    .replace(/<[^>]*>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"');
};

async function buildLetterHtml(letter) {
  // Resolve Sender Details
  const senderName = letter.sender ? `${letter.sender.firstName} ${letter.sender.lastName}` : (letter.senderName || "United");
  const senderPosition = letter.sender ? letter.sender.jobTitle : (letter.senderPosition || "Project Director");
  const senderOrganization = letter.sender ? (letter.sender.department || "United") : (letter.senderOrganization || "United");
  const senderEmail = letter.sender ? letter.sender.email : (letter.senderEmail || "info@united.co.tz");

  // Resolve Recipient Details
  const recipientName = letter.recipient ? letter.recipient.name : (letter.recipientName || "");
  const recipientPosition = letter.recipient ? letter.recipient.jobTitle : (letter.recipientPosition || "");
  const recipientOrganization = letter.recipient ? letter.recipient.organization : (letter.recipientOrganization || "");
  const recipientEmail = letter.recipient ? letter.recipient.email : (letter.recipientEmail || "");

  // Resolve CC Details
  let ccStakeholders = [];
  if (letter.ccList && letter.ccList.length) {
    const ids = [];
    const manual = [];
    letter.ccList.forEach(item => {
      if (typeof item === "string") {
        ids.push(item);
      } else if (item && typeof item === "object") {
        if (item.id) {
          ids.push(item.id);
        } else {
          manual.push(item);
        }
      }
    });
    if (ids.length) {
      const dbStakeholders = await Stakeholder.findAll({ where: { id: ids } });
      ccStakeholders = [...dbStakeholders, ...manual];
    } else {
      ccStakeholders = manual;
    }
  }

  return `
    <div style="font-family: 'Times New Roman', Times, serif; max-width: 800px; margin: 0 auto; padding: 40px; border: 1px solid #e5e7eb; background: #fff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); color: #111827;">
      <!-- LETTERHEAD -->
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #1a56db; padding-bottom: 15px; margin-bottom: 25px;">
        <div>
          <div style="font-size: 26px; font-weight: 800; color: #1a56db; letter-spacing: 1px;">UNITED</div>
          <div style="font-size: 10px; color: #4b5563; font-style: italic; margin-top: 2px;">Engineering & Technical Services</div>
        </div>
        <div style="text-align: right; font-size: 11px; color: #4b5563; line-height: 1.5;">
          <div style="font-weight: bold; color: #1f2937; font-size: 12px;">United Construction Group</div>
          <div>P.O. Box 12345, Dar es Salaam, Tanzania</div>
          <div>Tel: +255 22 212 3456 | Email: info@united.co.tz</div>
          <div>Website: www.united.co.tz</div>
        </div>
      </div>
      <!-- REF & DATE -->
      <div style="display: flex; justify-content: space-between; font-size: 13px; color: #4b5563; margin-bottom: 25px;">
        <div>Ref No: <strong style="color: #111827;">${letter.letterNo || 'DRAFT'}</strong></div>
        <div>Date: <strong style="color: #111827;">${new Date(letter.letterDate || letter.createdAt || Date.now()).toLocaleDateString("en-GB", { day: "2-digit", month: "long", year: "numeric" })}</strong></div>
      </div>
      <!-- TO -->
      <div style="margin-bottom: 20px; font-size: 14px;">
        <div style="font-size: 11px; color: #6b7280; text-transform: uppercase; margin-bottom: 3px;">To:</div>
        <div style="font-weight: bold; color: #111827;">${recipientName}${recipientPosition ? ", " + recipientPosition : ""}</div>
        ${recipientOrganization ? `<div>${recipientOrganization}</div>` : ""}
        ${recipientEmail ? `<div style="color:#6b7280;font-size:12px;">${recipientEmail}</div>` : ""}
      </div>
      <!-- SUBJECT -->
      <div style="margin-bottom: 25px;">
        <div style="font-size: 15px; font-weight: bold; text-decoration: underline; text-transform: uppercase; color: #111827;">
          SUBJECT: ${letter.subject}
        </div>
        ${letter.subTitle ? `<div style="font-size: 12px; font-weight: bold; color: #4b5563; margin-top: 5px; text-transform: uppercase;">${letter.subTitle}</div>` : ""}
      </div>
      <!-- BODY -->
      <div style="line-height: 1.6; font-size: 14px; margin-bottom: 40px; color: #111827;">${letter.body}</div>
      <!-- SIGN-OFF -->
      <div style="margin-top: 40px; font-size: 14px;">
        <div style="margin-bottom: 35px;">Yours faithfully,</div>
        <div style="font-weight: bold; text-decoration: underline; min-width: 180px; display: inline-block;">${senderName}</div>
        ${senderPosition ? `<div style="color:#4b5563;font-size:12px;">${senderPosition}</div>` : ""}
        ${senderOrganization ? `<div style="color:#4b5563;font-size:12px;">${senderOrganization}</div>` : ""}
      </div>
      <!-- CC -->
      ${
        ccStakeholders.length
          ? `<div style="margin-top: 30px; padding-top: 10px; border-top: 1px solid #e5e7eb; font-size: 13px; color: #4b5563;"><strong>CC:</strong><ul style="margin: 5px 0 0 0; padding-left: 20px;">${ccStakeholders.map((c) => `<li>${c.name} (${c.email})</li>`).join("")}</ul></div>`
          : ""
      }
      <!-- Attachment -->
      ${
        letter.attachmentFileName
          ? (() => {
              const ext = path.extname(letter.attachmentFileName).toLowerCase();
              const fileUrl = `/api/letters/${letter.id}/attachment/file`;
              let previewTag = "";
              if ([".jpg", ".jpeg", ".png", ".gif"].includes(ext)) {
                previewTag = `<div style="margin-top:10px;"><img src="${fileUrl}" style="max-width:100%; height:auto; border:1px solid #e5e7eb; border-radius:6px; box-shadow:0 1px 3px rgba(0,0,0,0.1);" /></div>`;
              } else if (ext === ".pdf") {
                previewTag = `<div style="margin-top:10px;"><iframe src="${fileUrl}" style="width:100%; height:600px; border:1px solid #e5e7eb; border-radius:6px; box-shadow:0 1px 3px rgba(0,0,0,0.1);"></iframe></div>`;
              }
              return `
                <div style="margin-top: 25px; padding-top: 15px; border-top: 1px solid #e5e7eb; font-size: 13px; color: #4b5563;">
                  <strong>Attachment:</strong> 
                  <a href="${fileUrl}" target="_blank" style="color: #1a56db; font-weight: bold; text-decoration: underline; margin-left: 5px;">
                    ${letter.attachmentFileName} ↗
                  </a>
                  ${previewTag}
                </div>
              `;
            })()
          : ""
      }
    </div>
  `;
}

// GET /api/letters/:letterId/preview  — inarudisha HTML moja kwa moja (si JSON)
// Frontend inatumia hii kama URL ya <iframe [src]> au kufungua tab mpya
exports.previewLetter = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId, { include: USER_INCLUDES });
    if (!letter) return res.status(404).send("<h3>Letter not found</h3>");

    res.set("Content-Type", "text/html");
    res.send(await buildLetterHtml(letter));
  } catch (err) {
    next(err);
  }
};

// GET /api/letters/:letterId/download  — inarudisha PDF (Blob) ya barua
exports.downloadLetterPdf = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId, { include: USER_INCLUDES });
    if (!letter) return errorResponse(res, "Letter not found", 404);

    // Resolve Sender Details
    const senderName = letter.sender ? `${letter.sender.firstName} ${letter.sender.lastName}` : (letter.senderName || "United");
    const senderPosition = letter.sender ? letter.sender.jobTitle : (letter.senderPosition || "Project Director");
    const senderOrganization = letter.sender ? (letter.sender.department || "United") : (letter.senderOrganization || "United");
    const senderEmail = letter.sender ? letter.sender.email : (letter.senderEmail || "info@united.co.tz");

    // Resolve Recipient Details
    const recipientName = letter.recipient ? letter.recipient.name : (letter.recipientName || "");
    const recipientPosition = letter.recipient ? letter.recipient.jobTitle : (letter.recipientPosition || "");
    const recipientOrganization = letter.recipient ? letter.recipient.organization : (letter.recipientOrganization || "");
    const recipientEmail = letter.recipient ? letter.recipient.email : (letter.recipientEmail || "");

    // Resolve CC Details
    let ccStakeholders = [];
    if (letter.ccList && letter.ccList.length) {
      const ids = [];
      const manual = [];
      letter.ccList.forEach(item => {
        if (typeof item === "string") {
          ids.push(item);
        } else if (item && typeof item === "object") {
          if (item.id) {
            ids.push(item.id);
          } else {
            manual.push(item);
          }
        }
      });
      if (ids.length) {
        const dbStakeholders = await Stakeholder.findAll({ where: { id: ids } });
        ccStakeholders = [...dbStakeholders, ...manual];
      } else {
        ccStakeholders = manual;
      }
    }

    // Use application/octet-stream and omit Content-Disposition to bypass IDM extension hijacking on AJAX requests
    res.setHeader("Content-Type", "application/octet-stream");

    const doc = new PDFDocument({ margin: 50 });
    const chunks = [];
    doc.on("data", (chunk) => chunks.push(chunk));
    doc.on("end", async () => {
      try {
        const letterPdfBuffer = Buffer.concat(chunks);
        let finalPdfBuffer = letterPdfBuffer;
        
        if (letter.attachmentFilePath) {
          const ext = path.extname(letter.attachmentFileName).toLowerCase();
          const attachPath = path.join(LETTERS_DIR, letter.attachmentFilePath);
          
          if (ext === ".pdf" && fs.existsSync(attachPath)) {
            const { PDFDocument: PDFLibDoc } = require("pdf-lib");
            const mergedPdf = await PDFLibDoc.create();
            
            const mainPdfDoc = await PDFLibDoc.load(letterPdfBuffer);
            const copiedPages = await mergedPdf.copyPages(mainPdfDoc, mainPdfDoc.getPageIndices());
            copiedPages.forEach((page) => mergedPdf.addPage(page));
            
            const attachBytes = fs.readFileSync(attachPath);
            const attachPdfDoc = await PDFLibDoc.load(attachBytes);
            const attachPages = await mergedPdf.copyPages(attachPdfDoc, attachPdfDoc.getPageIndices());
            attachPages.forEach((page) => mergedPdf.addPage(page));
            
            finalPdfBuffer = Buffer.from(await mergedPdf.save());
          }
        }
        res.end(finalPdfBuffer);
      } catch (err) {
        console.error("PDF Merge Error:", err);
        res.end(Buffer.concat(chunks));
      }
    });

    // Header
    doc.fontSize(9).fillColor("#6b7280")
      .text(`Ref: ${letter.letterNo || "DRAFT"}`, { continued: false })
      .text(`Date: ${new Date(letter.letterDate || letter.createdAt || Date.now()).toLocaleDateString("en-GB", { day: "2-digit", month: "long", year: "numeric" })}`);
    doc.moveTo(50, doc.y + 5).lineTo(545, doc.y + 5).strokeColor("#1a56db").lineWidth(2).stroke();
    doc.moveDown(1.5);

    // To
    doc.fillColor("#111827").fontSize(11).font("Helvetica-Bold")
      .text(`To: ${recipientName}${recipientPosition ? ", " + recipientPosition : ""}`);
    doc.font("Helvetica").fontSize(10).fillColor("#374151");
    if (recipientOrganization) doc.text(recipientOrganization);
    if (recipientEmail) doc.fillColor("#6b7280").text(recipientEmail);
    doc.moveDown();

    // Subject
    doc.fillColor("#111827").fontSize(12).font("Helvetica-Bold").text(`Subject: ${letter.subject}`);
    if (letter.subTitle) {
      doc.fontSize(10).font("Helvetica-BoldOblique").fillColor("#374151").text(letter.subTitle);
    }
    doc.moveDown();

    // Body (stripping HTML tags for PDF Kit)
    doc.font("Helvetica").fontSize(11).fillColor("#111827").text(stripHtml(letter.body), { align: "left", lineGap: 4 });
    doc.moveDown(3);

    // Sender
    doc.fontSize(11).text(senderName);
    if (senderPosition) doc.fontSize(9).fillColor("#6b7280").text(senderPosition);
    if (senderOrganization) doc.fontSize(9).fillColor("#6b7280").text(senderOrganization);
    doc.moveDown();

    // CC List at the bottom
    if (ccStakeholders.length) {
      doc.fillColor("#111827").fontSize(10).font("Helvetica-Bold").text("CC:", { continued: false });
      doc.font("Helvetica").fontSize(9).fillColor("#4b5563");
      ccStakeholders.forEach((c) => {
        doc.text(`- ${c.name} (${c.email})`);
      });
    }

    // Attachment at the bottom
    if (letter.attachmentFileName) {
      doc.moveDown();
      doc.fillColor("#111827").fontSize(10).font("Helvetica-Bold").text("Attachment:", { continued: false });
      doc.font("Helvetica").fontSize(9).fillColor("#1a56db").text(letter.attachmentFileName);

      // If it's a JPEG or PNG image, embed it on a new page natively!
      const ext = path.extname(letter.attachmentFileName).toLowerCase();
      const attachPath = path.join(LETTERS_DIR, letter.attachmentFilePath);
      if ([".jpg", ".jpeg", ".png"].includes(ext) && fs.existsSync(attachPath)) {
        doc.addPage();
        doc.image(attachPath, 50, 50, { fit: [500, 700], align: 'center', valign: 'center' });
      }
    }

    doc.end();
  } catch (err) {
    next(err);
  }
};

// GET /api/letters/:letterId/attachment/download
exports.downloadAttachment = async (req, res, next) => {
  try {
    const letter = await OfficialLetter.findByPk(req.params.letterId);
    if (!letter || !letter.attachmentFilePath) return errorResponse(res, "Attachment not found", 404);

    const filePath = path.join(LETTERS_DIR, letter.attachmentFilePath);
    if (!fs.existsSync(filePath)) return errorResponse(res, "File not found on server", 404);

    const { download } = req.query;
    if (download === "true") {
      res.download(filePath, letter.attachmentFileName);
    } else {
      res.sendFile(filePath);
    }
  } catch (err) {
    next(err);
  }
};
