const express = require('express');
const router = express.Router();

router.use('/auth',           require('./auth.routes'));
router.use('/users',          require('./users.routes'));
router.use('/roles',          require('./roles.routes'));
router.use('/clients',        require('./clients.routes'));
router.use('/phases',         require('./phases.routes'));
router.use('/activity-types', require('./activityTypes.routes'));
router.use('/suppliers',      require('./suppliers.routes'));
router.use('/stakeholders',   require('./stakeholders.routes'));
router.use('/products',       require('./products.routes'));
router.use('/units',          require('./units.routes'));
router.use('/store/central',  require('./central.store.routes'));
router.use('/projects',       require('./projects.routes'));
router.use('/letters',        require('./letters.routes'));

module.exports = router;
